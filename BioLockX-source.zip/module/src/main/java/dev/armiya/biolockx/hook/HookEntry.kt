package dev.armiya.biolockx.hook

/*
 * Deliberately an integration placeholder.
 *
 * The final lock hook must be implemented against the exact libxposed API
 * version and tested on the target Android build. Do not claim protection
 * until Activity lifecycle interception and pre-draw blocking are validated.
 *
 * This file intentionally does not intercept or modify other applications.
 */
