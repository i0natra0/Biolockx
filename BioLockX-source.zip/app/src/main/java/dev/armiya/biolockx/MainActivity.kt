package dev.armiya.biolockx

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.content.SharedPreferences

private val Bg = Color(0xFF0D0E13)
private val Panel = Color(0xFF1B1C25)
private val Lilac = Color(0xFFD0BEFF)

class MainActivity : ComponentActivity() {
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("biolock_settings", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Lilac,
                onBackground = Color.White, onSurface = Color.White
            )) {
                BioLockHome(
                    prefs = prefs,
                    packages = loadLaunchableApps(),
                    onTestBiometric = { authenticate() }
                )
            }
        }
    }

    private fun loadLaunchableApps(): List<AppEntry> {
        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == packageName) return@mapNotNull null
                AppEntry(pkg, info.loadLabel(packageManager).toString())
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private fun authenticate() {
        val allowed = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val status = BiometricManager.from(this).canAuthenticate(allowed)
        if (status != BiometricManager.BIOMETRIC_SUCCESS) return
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {})
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("BioLock X")
                .setSubtitle("برای آزمایش، هویت خود را تأیید کن")
                .setAllowedAuthenticators(allowed)
                .build()
        )
    }
}

data class AppEntry(val packageName: String, val label: String)

@Composable
private fun BioLockHome(
    prefs: SharedPreferences,
    packages: List<AppEntry>,
    onTestBiometric: () -> Unit
) {
    var enabled by remember { mutableStateOf(prefs.getBoolean("enabled", false)) }
    var delay by remember { mutableIntStateOf(prefs.getInt("delay", 15)) }
    val selected = remember { mutableStateListOf<String>().apply {
        addAll(prefs.getStringSet("selected", emptySet()) ?: emptySet())
    } }

    Surface(Modifier.fillMaxSize(), color = Bg) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF222033), Bg, Bg))
            ),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("◈", color = Lilac, style = MaterialTheme.typography.headlineLarge)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("BioLock X", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Privacy, with a softer touch", color = Color.LightGray)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(26.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("قفل برنامه‌ها", fontWeight = FontWeight.Bold)
                                Text("تنظیمات نسخه آزمایشی", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = enabled, onCheckedChange = {
                                enabled = it; prefs.edit().putBoolean("enabled", it).apply()
                            })
                        }
                        Text("تأخیر قفل مجدد", color = Lilac)
                        listOf(0, 5, 15, 30, 60).forEach { seconds ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = delay == seconds, onClick = {
                                    delay = seconds; prefs.edit().putInt("delay", seconds).apply()
                                })
                                Text(if (seconds == 0) "فوری" else "$seconds ثانیه")
                            }
                        }
                        Button(onClick = onTestBiometric, modifier = Modifier.fillMaxWidth()) {
                            Text("آزمایش اثر انگشت")
                        }
                    }
                }
            }
            item {
                Text("برنامه‌های انتخاب‌شده", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("برنامه‌هایی را که بعداً باید قفل شوند انتخاب کن.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
            items(packages) { app ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(app.label, fontWeight = FontWeight.Medium)
                            Text(app.packageName, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                        }
                        Checkbox(checked = app.packageName in selected, onCheckedChange = { checked ->
                            if (checked) selected.add(app.packageName) else selected.remove(app.packageName)
                            prefs.edit().putStringSet("selected", selected.toSet()).apply()
                        })
                    }
                }
            }
            item {
                Text(
                    "هشدار: این بیلد فقط رابط تنظیمات و آزمایش بیومتریک دارد؛ Hook قفل هنوز فعال نیست.",
                    color = Color(0xFFFFC58B),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
