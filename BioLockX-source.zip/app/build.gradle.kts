plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")\n    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "dev.armiya.biolockx"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.armiya.biolockx"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
    }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "2.1.20" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.03.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.biometric:biometric:1.2.0-alpha05")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
