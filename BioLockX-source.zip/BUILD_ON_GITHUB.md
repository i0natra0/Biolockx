# ساخت از روی گوشی

1. در GitHub یک repository جدید بساز.
2. فایل‌های این ZIP را در ریشه repository آپلود کن.
3. به Actions برو و `Build Android APKs` را اجرا کن.
4. خروجی `BioLockX-debug-apks` را از اجرای موفق دانلود کن.

اگر workflow به دلیل نبودن Gradle شکست خورد، باید Gradle Wrapper به repository اضافه شود؛ این پروژه در حال حاضر اسکلت توسعه است و APK نهاییِ ماژول Hook تولید نمی‌کند.
